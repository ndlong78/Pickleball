/* PickleUp V2.5 — guided on-court player for personalized plans. */
(function(){
"use strict";
const clock=window.PICKLEUP_PRACTICE_CLOCK,draw=window.PICKLEUP_DRILL_DIAGRAM;
if(!clock)return;
const storageKey="pickleup_practice_state_v25",plansKey="pickleup_plans_v24",$=id=>document.getElementById(id);
let plan=null,state=null,lastExpired=-1,wakeLock=null,wakeWanted=false,renderedDrillKey=null;
const plansSource=window.PICKLEUP_PLANS,activity=window.PICKLEUP_ACTIVITY;
const checkpoint=window.PICKLEUP_COURT_CHECKPOINT;
let attemptBusy=false,activityToken=activity?.token();
let planToken=plansSource?.token();
const logApi=window.PICKLEUP_TRAINING_LOG,conditionsApi=window.PICKLEUP_PRACTICE_CONDITIONS;
function read(key,fallback){try{return JSON.parse(localStorage.getItem(key)||"null")??fallback}catch(_){return fallback}}
function save(){if(plansSource?.isAccount())return;try{if(state)localStorage.setItem(storageKey,JSON.stringify(state))}catch(_){message("Không lưu được trạng thái đồng hồ; hãy giữ trang đang mở.")}}
function message(value){$("pcRunMessage").textContent=value}
function checkpointControls(){
 const panel=$("pcCheckpointPanel");if(!panel)return;panel.hidden=!plan||!plansSource?.isAccount();
 $("pcCheckpointStatus").textContent=checkpoint?.notice()||'';$("pcCheckpointSave").disabled=!checkpoint?.canSave();$("pcCheckpointRestore").disabled=!checkpoint?.canRestore();
 const s=checkpoint?.getState();$("pcCheckpointRead").disabled=!!s?.busy||s?.mode==='loading';$("pcCheckpointRetry").hidden=!s?.error||s.stale;$("pcCheckpointRetry").disabled=!!s?.busy;
}
async function saveCheckpoint(){
 if(!plan||!state||!checkpoint?.canSave())return;
 const stamp=checkpoint.token(),sourceStamp=plansSource?.token(),id=plan.id;
 if(checkpoint.getState().row?.value&&!confirm('Thay điểm dừng đã lưu của giáo án này bằng vị trí đang tập? Đồng hồ sẽ tạm dừng; không xác nhận buổi tập.'))return;
 if(stamp!==checkpoint.token()||sourceStamp!==plansSource?.token()||plan?.id!==id||!checkpoint.canSave())return;state=clock.pause(state);render();await checkpoint.save(state);
}
async function restoreCheckpoint(){
 if(!plan||!checkpoint?.canRestore())return;const stamp=checkpoint.token(),sourceStamp=plansSource?.token(),id=plan.id;
 if(!confirm('Khôi phục điểm dừng đã xem? Đồng hồ sẽ dừng; vị trí đang tập trong phiên này được thay bằng điểm dừng.')||stamp!==checkpoint.token()||sourceStamp!==plansSource?.token()||plan?.id!==id)return;
 const value=await checkpoint.restore();
 if(!value||stamp!==checkpoint.token()||sourceStamp!==plansSource?.token()||plan?.id!==id)return;
 state={planId:id,index:value.index,remaining:value.remaining,ended:value.ended,running:false,deadline:null};lastExpired=-1;render();message('Đã khôi phục điểm dừng; nhấn Bắt đầu khi sẵn sàng. Không tự xác nhận buổi tập.');
}
document.addEventListener('pickleup:court-checkpoint-data',checkpointControls);
function phaseInfo(index){
 if(!plan||index>=clock.stages.length)return null;
 const step=clock.stages[index];
 if(index===0||index===5)return {name:step.title,minutes:step.minutes,info:step.description,skill:null,exercise:null};
 if(index>=1&&index<=3){const e=plan.exercises[index-1];return {name:step.title+" · "+e.skillName,minutes:step.minutes,info:e.instructions,skill:e.skill,exercise:e}}
 const c=plan.checkpoint;
 return {name:step.title+" · "+(window.PICKLEUP_ADVANCED_COACH?.names[c.skill]||window.PICKLEUP_PERSONAL_CORE?.names[c.skill]||c.skill),minutes:6,info:"Thực hiện 20 lượt kiểm tra kỹ năng ưu tiên số một. Mốc trước tập "+c.baseline+"/20, mục tiêu tham khảo "+c.target+"/20. Chỉ tính lượt hợp lệ đúng mục tiêu.",skill:c.skill,exercise:plan.exercises[0]};
}
function loadPlan(p){
 if(!p||!p.id||!Array.isArray(p.exercises)||p.exercises.length!==3){plan=null;state=null;renderedDrillKey=null;wakeWanted=false;wakeLock?.release().catch(()=>{});wakeLock=null;if($("pcWakeToggle"))$("pcWakeToggle").checked=false;render();return}
 const old=plansSource?.isAccount()?null:read(storageKey,null),changing=plan?.id!==p.id;
 plan=p;if(changing){state=clock.readStored(old,plan.id);lastExpired=-1}
 render();
}
function render(){
 const enabled=!!plan;
 checkpointControls();
 $("pcRunEmpty").hidden=enabled;$("pcRunPlayer").hidden=!enabled;
 if(!enabled){$("pcRunGuide").replaceChildren();$("pcRunDiagram").replaceChildren();$("pcRunSegments").replaceChildren();$("pcRunTitle").textContent="";$("pcRunStep").textContent="";$("pcRunClock").textContent="00:00";return;}
 if(!state)state=clock.create(plan.id);
 const done=state.index>=clock.stages.length;
 const info=phaseInfo(state.index);
 $("pcRunTitle").textContent=done?"Đã kết thúc thời gian tập":info.name;
 $("pcRunStep").textContent=done?"Đã hoàn thành 6 phần thời gian — hãy ghi kết quả kiểm tra.":"Phần "+(state.index+1)+"/6 · "+info.minutes+" phút · Giáo án "+plan.level;
 $("pcRunClock").textContent=clock.fmt(clock.seconds(state));
 $("pcRunStart").textContent=state.running?"Tạm dừng":"Bắt đầu";
 $("pcRunStart").disabled=done||state.remaining===0;
 $("pcRunPrev").disabled=state.index===0;
 $("pcRunNext").disabled=done;
 $("pcRunNext").textContent=state.index===clock.stages.length-1?"Kết thúc giờ tập":state.remaining===0?"Phần tiếp theo":"Bỏ qua sang phần sau";
 $("pcRunProgress").style.width=(done?100:(state.index/clock.stages.length*100))+"%";
 const guide=$("pcRunGuide"),diagram=$("pcRunDiagram");
 guide.replaceChildren();diagram.replaceChildren();
 if(done){const p=document.createElement("p");p.textContent="Bạn đã đi hết sáu phần của đồng hồ. Hãy ghi lại kết quả kiểm tra để giáo án sau phù hợp hơn.";guide.append(p)}
 else {
  const heading=document.createElement("h4");heading.textContent=info.name;guide.append(heading);
  const p=document.createElement("p");p.textContent=info.info;guide.append(p);
  if(info.exercise){
   const setup=document.createElement("p");setup.textContent="Bố trí: "+info.exercise.setup;guide.append(setup);
   const measure=document.createElement("p");measure.textContent="Đánh giá: "+info.exercise.measure;guide.append(measure);
   const caution=document.createElement("p");caution.textContent="Tránh: "+info.exercise.mistake;guide.append(caution);
   if(info.exercise.advanced&&window.PICKLEUP_ADVANCED_COURT){diagram.innerHTML=window.PICKLEUP_ADVANCED_COURT(info.exercise)}else if(typeof draw==="function")draw(diagram,info.exercise);
  }
 }
 const items=$("pcRunSegments");items.replaceChildren();
 clock.stages.forEach((s,i)=>{const el=document.createElement("span");el.className="pc-run-segment"+(i===state.index?" is-active":"")+(i<state.index?" is-done":"");el.textContent=(i+1)+". "+s.title;items.append(el)});
 $("pcRunScore").hidden=!done&&state.index!==4;
 const active=state.index>=1&&state.index<=3||state.index===4&&plansSource?.isAccount();
 for(const id of ["pcAttemptHits","pcAttemptNote","pcAttemptFeed","pcAttemptPace","pcAttemptTarget"])$(id).disabled=attemptBusy;
 $("pcAttemptArea").hidden=!active;$("pcAttemptSave").disabled=attemptBusy||(plansSource?.isAccount()? !activity?.canTrain(plan.id):activity?.isAccount()===true);
 if(active){
  const drill=plan.exercises[state.index===4?0:state.index-1],drillKey=plan.id+"|"+drill.id+"|"+(state.index===4?"assessment":"drill");
  if(renderedDrillKey!==drillKey){$("pcAttemptHits").value="";$("pcAttemptNote").value="";renderedDrillKey=drillKey}
  $("pcAttemptName").textContent=(state.index===4?"Ghi một lượt kiểm tra riêng: ":"Ghi một lần tập: ")+drill.skillName+" — "+drill.name;
  $("pcAttemptHint").textContent=plansSource?.isAccount()?(activity?.canTrain(plan.id)?"Kho hoạt động tài khoản · lưu một lượt mới trên thiết bị, gửi khi bấm đồng bộ hoạt động. Không sửa điểm giáo án hoặc xác nhận buổi tập.":"Để ghi lượt tập, chọn kho hoạt động cùng tài khoản trong Dữ liệu và đồng bộ giáo án đã chọn. Chưa ghi vào kho khách."):activity?.isAccount()?"Nhật ký đang dùng kho tài khoản. Chọn và đồng bộ giáo án tài khoản trong Dữ liệu trước khi ghi lượt tập.":"Sau phần luyện kỹ thuật, kiểm tra 20 lượt với cùng mục tiêu, cùng cấp độ và ghi số lần đúng. Mục tiêu 20 lượt này riêng với các hiệp trong hướng dẫn.";
 }else renderedDrillKey=null;
}
function advance(direction){
 if(!state)return;
 state=clock.step(state,direction,Date.now());save();lastExpired=-1;render();
 message(state.ended?"Đã hoàn tất sáu phần thời gian. Ghi kết quả ở cuối giáo án.":"Đã chuyển phần. Nhấn Bắt đầu khi bạn sẵn sàng.");
}
function startPause(){
 if(!state)return;
 state=state.running?clock.pause(state):clock.start(state);
 save();render();
 message(state.running?"Đang đếm ngược cho phần này.":"Đồng hồ đã tạm dừng.");
}
function reset(){
 if(!state||!confirm("Đặt lại đồng hồ về phần khởi động của kế hoạch này?"))return;
 state=clock.reset(state);save();lastExpired=-1;render();message("Đã đặt lại đồng hồ.");
}
async function saveAttempt(){
 if(attemptBusy||!plan||!state||state.index<1||state.index>4||!logApi)return;
 const account=plansSource?.isAccount()===true,sourceStamp=plansSource?.token(),activityStamp=activity?.token(),key=renderedDrillKey;
 if(account?!activity?.canTrain(plan.id):activity?.isAccount()){message("Chọn cùng nguồn giáo án và hoạt động trước khi ghi lượt tập; chưa ghi vào kho khách.");return}
 const drill=plan.exercises[state.index===4?0:state.index-1],input=$("pcAttemptHits"),value=input.value.trim(),hits=Number(value);
 if(!value||!Number.isInteger(hits)||hits<0||hits>20){message("Vui lòng nhập số nguyên từ 0 đến 20 cho bài tập.");return}
 try{
  const conditions=conditionsApi?.fromSelect({feed:$("pcAttemptFeed").value,pace:$("pcAttemptPace").value,target:$("pcAttemptTarget").value});
  if(!conditions)throw Error("Hãy chọn đủ cách cấp bóng, tốc độ và vùng mục tiêu để ghi lượt tập có thể so sánh.");
  const value={planId:plan.id,exerciseId:drill.id,skill:drill.skill,level:plan.level,kind:state.index===4?"assessment":"drill",hits,note:$("pcAttemptNote").value,conditions};
  attemptBusy=true;render();message("Đang lưu lượt tập…");
  if(account)await activity.saveTraining(value);else logApi.record(localStorage,value);
  if(sourceStamp!==plansSource?.token()||activityStamp!==activity?.token()||key!==renderedDrillKey)return;
  input.value="";$("pcAttemptNote").value="";
  message((account?"Đã lưu trong kho tài khoản trên thiết bị · chờ đồng bộ hoạt động. ":"")+"Đã lưu "+hits+"/20 cho "+drill.skillName+". Có thể ghi thêm lần tập khác.");
  document.dispatchEvent(new Event("pickleup:training-log-updated"));
 }catch(e){if(sourceStamp===plansSource?.token()&&activityStamp===activity?.token()&&key===renderedDrillKey)message(account?(window.PickleUpActivityHistory?.error(e)||"Chưa lưu được. Giữ dữ liệu nhập và kiểm tra Dữ liệu."):"Không thể lưu lần tập: "+e.message)}
 finally{if(sourceStamp===plansSource?.token()&&activityStamp===activity?.token()){attemptBusy=false;render()}}
}
async function toggleWake(){
 const sourceStamp=plansSource?.token();
 if(!("wakeLock" in navigator)){
  $("pcWakeToggle").checked=false;
  message("Trình duyệt này chưa hỗ trợ giữ màn hình sáng. Hãy điều chỉnh thời gian khóa màn hình trên điện thoại.");
  return;
 }
 wakeWanted=$("pcWakeToggle").checked;
 if(!wakeWanted){try{if(wakeLock)await wakeLock.release()}catch(_){}wakeLock=null;return}
 try{
  const acquired=await navigator.wakeLock.request("screen");
  if(sourceStamp!==plansSource?.token()||!wakeWanted){await acquired.release();return}
  wakeLock=acquired;wakeLock.addEventListener?.("release",()=>{if(wakeLock===acquired)wakeLock=null});
  message("Đã yêu cầu giữ màn hình sáng. Tính năng có thể tự ngắt khi khóa màn hình hoặc tiết kiệm pin.");
 }catch(e){if(sourceStamp!==plansSource?.token())return;wakeWanted=false;$("pcWakeToggle").checked=false;message("Không bật được giữ màn hình sáng trên thiết bị này.")}
}
function pulse(){
 if(!state||!state.running)return;
 const old=state;state=clock.tick(state);
 // Avoid rebuilding text/diagram every quarter-second; update only the clock.
 $("pcRunClock").textContent=clock.fmt(clock.seconds(state));
 if(old.running&&!state.running&&state.remaining===0){
  save();render();
  if(lastExpired!==state.index){lastExpired=state.index;message("Đã hết thời gian phần này. Chọn Phần tiếp theo khi sẵn sàng.")}
 }
}
document.addEventListener("pickleup:plan-data",()=>{
 const next=plansSource?.token();if(next!==planToken){planToken=next;attemptBusy=false;plan=null;state=null;lastExpired=-1;renderedDrillKey=null;wakeWanted=false;wakeLock?.release().catch(()=>{});wakeLock=null;
 for(const id of ['pcAttemptHits','pcAttemptNote','pcAttemptFeed','pcAttemptPace','pcAttemptTarget'])if($(id))$(id).value='';if($("pcWakeToggle"))$("pcWakeToggle").checked=false;message('');loadPlan(plansSource?.selected()||null)}
});
document.addEventListener("pickleup:activity-data",()=>{const next=activity?.token();if(next!==activityToken){activityToken=next;attemptBusy=false;for(const id of ["pcAttemptHits","pcAttemptNote","pcAttemptFeed","pcAttemptPace","pcAttemptTarget"])if($(id))$(id).value="";message("")}render()});
document.addEventListener("pickleup:plan-selected",event=>loadPlan(plansSource?.isAccount()?plansSource.selected():event.detail?.plan||null));
(window.PICKLEUP_READY || (fn=>document.addEventListener("DOMContentLoaded",fn)))(()=>{
 const cond=window.PICKLEUP_PRACTICE_CONDITIONS;
 if(cond){
  const ids={feed:"pcAttemptFeed",pace:"pcAttemptPace",target:"pcAttemptTarget"};
  for(const [kind,id] of Object.entries(ids)){
   const field=$(id);
   if(field&&field.options.length<=1)for(const [value,label] of Object.entries(cond.OPTIONS[kind])){
    const item=document.createElement("option");item.value=value;item.textContent=label;field.append(item);
   }
  }
 }
 if(!$("pcOnCourt"))return;
 const selected=$("pcPlan")?.dataset.planId;
 const plans=read(plansKey,[]);
 if(plansSource?.isAccount())loadPlan(plansSource.selected());else if(selected&&Array.isArray(plans))loadPlan(plans.find(p=>p.id===selected)||null);else render();
 $("pcOpenRun")?.addEventListener("click",()=>{window.PICKLEUP_ROUTER?.openSection("pcOnCourt")||$("pcOnCourt").scrollIntoView({behavior:"smooth",block:"start"})});
 $("pcAttemptSave").addEventListener("click",saveAttempt);
 $("pcWakeToggle").addEventListener("change",toggleWake);
 $("pcRunStart").addEventListener("click",startPause);
 $("pcRunPrev").addEventListener("click",()=>advance(-1));
 $("pcRunNext").addEventListener("click",()=>advance(1));
 $("pcRunReset").addEventListener("click",reset);
 $("pcCheckpointSave")?.addEventListener('click',saveCheckpoint);
 $("pcCheckpointRestore")?.addEventListener('click',restoreCheckpoint);
 $("pcCheckpointRead")?.addEventListener('click',()=>checkpoint?.refresh());
 $("pcCheckpointRetry")?.addEventListener('click',()=>checkpoint?.retry());
 $("pcRunScore").addEventListener("click",async()=>{if(!plan)return;const id=plan.id,version=plan.version,stamp=plansSource?.token();window.PICKLEUP_ROUTER?.openSection(version==='3.1'?'advancedCoach':'personalCoach');try{await window.PICKLEUP_PAGE_LOADER?.ensure('coach');if(stamp!==plansSource?.token()||plan?.id!==id)return;document.dispatchEvent(new CustomEvent('pickleup:plan-score-request',{detail:{id,version}}));$(version==='3.1'?'acCoachResult':'pcPostScore')?.focus()}catch(_){if(stamp===plansSource?.token())message('Chưa mở được phần kết quả; thử lại khi có mạng.')}});
 // Wall-clock deadlines recover from mobile background throttling without incorrectly skipping stages.
 setInterval(pulse,350);
 document.addEventListener("visibilitychange",()=>{
 if(!document.hidden&&state){state=clock.tick(state);save();render()}
 if(!document.hidden&&wakeWanted&&!wakeLock)toggleWake();
});
});
})();
